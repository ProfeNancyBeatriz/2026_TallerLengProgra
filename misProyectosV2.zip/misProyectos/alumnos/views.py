from django.shortcuts import render
from .models import Alumno, Genero

# Create your views here.


def index(request):
    alumnos = Alumno.objects.all() #Equivale a SELECT * FROM....
    context = {"alumnos" : alumnos}
    return render(request, 'alumnos/index.html', context)

def crud(request):
    alumnos = Alumno.objects.all()
    context = {"alumnos" : alumnos}
    return render(request, 'alumnos/alumnos_list.html', context)

def alumnosAdd(request):
    generos = Genero.objects.all()#Equivale a SELECT * FROM Genero
    if request.method != "POST":
        #GET; viene del botón Agregar, se muestra el formulario
        return render(request, 'alumnos/alumnos_add.html',{'generos': generos})

    #POST: viene del formulario, se graban los datos
    objGenero = Genero.objects.get(id_genero=request.POST["genero"])

    Alumno.objects.create(#crea el objetoy lo graba en un solo paso
        rut=request.POST["rut"],
        nombre=request.POST["nombre"],
        apellido_paterno= request.POST["paterno"],
        apellido_materno= request.POST["materno"],
        fecha_nacimiento= request.POST["fechaNac"],
        id_genero = objGenero,
        telefono=request.POST["telefono"],
        email=request.POST["email"],
        direccion=request.POST["direccion"],
        activo=1
    )
    context = {'generos': generos, 'mensaje': "Ok, datos garabados..."}
    return render(request, 'alumnos/alumnos_add.html')

def alumnos_del(request, pk):
    try:
        Alumno.objects.get(rut = pk).delete()
        mensaje = "Bien, datos eliminados..."
    except Alumno.DoesNotExist:
        mensaje = "Error, RUT NO existe!!!"
    context = {'alumnos' : Alumno.objects.all(), 'mensaje': mensaje}
    return render(request, 'alumnos/alumnos_list.html', context)

def alumnos_findEdit(request, pk):
    alumno = Alumno.objects.get(rut = pk)
    context = {'alumno' : alumno, 'generos': Genero.objects.all()}
    return render(request, 'alumnos/alumnos_edit.html', context)

def alumnosUpdate(request):
    alumno = Alumno.objects.get(rut=request.POST["rut"])
    alumno.nombre=request.POST["nombre"],
    alumno.apellido_paterno= request.POST["paterno"],
    alumno.apellido_materno= request.POST["materno"],
    alumno.fecha_nacimiento= request.POST["fechaNac"],
    alumno.id_genero = Genero.objects.get(id_genero = request.POST["genero"]),
    alumno.telefono=request.POST["telefono"],
    alumno.email=request.POST["email"],
    alumno.direccion=request.POST["direccion"]
    alumno.save()
    context = {'alumno': alumno, 'generos': Genero.objects.all(),
               'mensaje': "Ok, datos actualizados correctamente..."}
    return render(request, 'alumnos/alumnos_edit.html', context)
