// Marca en el menú la página actual
document.querySelectorAll(".menu a").forEach(function (enlace) {
    if (enlace.getAttribute("href") === window.location.pathname) {
        enlace.classList.add("activo");
    }
});

// Oculta el mensaje (div idMensajes) después de 3 segundos
var mensaje = document.getElementById("idMensajes");
if (mensaje) {
    setTimeout(function () { mensaje.style.display = "none"; }, 3000);
}
