from django.contrib import admin

# Registrar aquí los modelos para verlos en el administrador. 
from .models import Genero, Alumno
admin.site.register(Genero)
admin.site.register(Alumno)