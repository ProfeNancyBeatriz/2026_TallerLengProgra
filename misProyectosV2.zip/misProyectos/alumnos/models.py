from django.db import models

# Aquí se construyen los modelos de la app alumnos.
# Después de crearlos ejecutar:
#   python manage.py makemigrations
#   python manage.py migrate

class Genero(models.Model):
    id_genero = models.AutoField(db_column='idGenero',primary_key=True)
    genero= models.CharField(max_length=20)

    def __str__(self):
        return str(self.genero)

class Alumno(models.Model):
    rut = models.CharField(primary_key=True, max_length=10)
    nombre = models.CharField(max_length=20)
    apellido_paterno = models.CharField(max_length=20)
    apellido_materno = models.CharField(max_length=20)
    fecha_nacimiento = models.DateField()
    id_genero = models.ForeignKey('Genero', on_delete=models.CASCADE,db_column='idGenero')
    telefono= models.CharField(max_length=45)
    email= models.EmailField(unique=True, max_length=100, blank=True, null=True)
    direccion = models.CharField(max_length=50, blank=True, null=True)
    activo = models.IntegerField()
    def __str__(self):
                return str(self.nombre) + " " + str(self.apellido_paterno)