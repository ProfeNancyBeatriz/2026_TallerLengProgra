from django.contrib import admin
from django.urls import path, include
from django.views.generic import RedirectView

urlpatterns = [
    path('admin/', admin.site.urls),
    path('alumnos/', include('alumnos.urls')),
    # La raíz del sitio redirige a la página de inicio de la app
    path('', RedirectView.as_view(url='/alumnos/index')),
]
